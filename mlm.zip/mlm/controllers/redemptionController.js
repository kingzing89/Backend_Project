const RedemptionRequest = require('../models/redemptionRequestsModel');
const Member = require('../models/membersModel');

const submitRedemptionRequest = async (req, res) => {
  try {
    const { memberId, pointsRequested, requestType } = req.body;

    // Validate the input (You may want to add more validation)
    if (!memberId || !pointsRequested || !requestType) {
      return res.status(400).json({ error: 'Missing required fields.' });
    }

    // Check if the member exists
    const member = await Member.findByPk(memberId);
    if (!member) {
      return res.status(404).json({ error: 'Member not found.' });
    }

    // Create the redemption request
    const redemptionRequest = await RedemptionRequest.create({
      MemberID: memberId,
      RequestDate: new Date(),
      PointsRequested: pointsRequested,
      RequestType: requestType,
      Status: 'Pending', // You can set an initial status
      AdminID: null, // You may assign an admin if needed
    });

    return res.status(201).json({ message: 'Redemption request submitted successfully.' });
  } catch (error) {
    console.error('Error submitting redemption request:', error);
    res.status(500).json({ error: 'An error occurred while processing your request.' });
  }
};

const getAllPendingRedemptionRequests = async (req, res) => {
    try {
      // Find all pending redemption requests
      const pendingRequests = await RedemptionRequest.findAll({
        where: { Status: 'Pending' },
      });
  
      return res.status(200).json({ pendingRequests });
    } catch (error) {
      console.error('Error fetching pending redemption requests:', error);
      res.status(500).json({ error: 'An error occurred while processing your request.' });
    }
  };

  const updateRedemptionRequestStatus = async (req, res) => {
    try {
      const { requestId, newStatus } = req.body; // Get the requestId and newStatus from the request body
  
      // Find the redemption request by ID
      const redemptionRequest = await RedemptionRequest.findByPk(requestId);
  
      if (!redemptionRequest) {
        return res.status(404).json({ error: 'Redemption request not found.' });
      }
  
      // Update the status of the redemption request
      redemptionRequest.Status = newStatus;

       // If the new status is "Approved," update member balances
    if (newStatus === 'Approved') {
        const member = await Member.findByPk(redemptionRequest.MemberID);
  
        if (member) {
          // Deduct points from the member's Balance
          member.Balance = parseInt(member.Balance, 10) -  redemptionRequest.PointsRequested;
  
          // Add points to the member's AvailableBalance
          member.AvailableBalance = parseInt(member.AvailableBalance,10) + redemptionRequest.PointsRequested;
  
          // Save the updated member details
          await member.save();
        } else {
          return res.status(404).json({ error: 'Member not found.' });
        }
      }


  
      // Save the updated request
      await redemptionRequest.save();
  
      return res.status(200).json({ message: 'Redemption request status updated successfully.' });
    } catch (error) {
      console.error('Error updating redemption request status:', error);
      res.status(500).json({ error: 'An error occurred while processing your request.' });
    }
  };

  async function getAllRedemptionRequestsBymemberID(req, res) {
    try {
      let memberID = req.params;
      const redemptionRequests = await RedemptionRequest.findAll({
        where: {
          MemberID: memberID
        },
    });
  
      res.json(redemptionRequests);
    } catch (error) {
      res.status(500).json({ error: 'Internal Server Error' });
    }
  }

module.exports = {
  submitRedemptionRequest, getAllPendingRedemptionRequests, updateRedemptionRequestStatus,getAllRedemptionRequestsBymemberID
};
