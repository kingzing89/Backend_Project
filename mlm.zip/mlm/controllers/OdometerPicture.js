// odometer controller:


// odometerPictureController.js
const axios = require('axios');
const Member = require('../models/membersModel');
const Recruit = require('../models/recruitsModel');
const fs = require('fs');
const { Op } = require('sequelize');
const OdometerPictureModel  = require('../models/odometerPicturesModel');

  let addOdometer = async (req, res) => {
  try {
    let { MemberID, SubmissionDate, ApprovalStatus, ReasonForRejection, Distance, OdometerPicture } = req.body;
    // const downloadImage = async (imageUrl) => {
    //   try {
        
    //     let imageBuffer = Buffer.from(imageUrl, 'binary');
    //     return imageBuffer;
    //   } catch (error) {
    //     throw new Error(`Error downloading image from ${imageUrl}: ${error.message}`);
    //   }
    // };

    
     

    // let imageUrl = OdometerPicture;
    // let imageData = await downloadImage(imageUrl); // Function to download image (explained below)
    // let  base64EncodedImage = imageData.toString('base64');
    const imageData = fs.readFileSync(OdometerPicture);

    const mimeType = `image/${OdometerPicture.split('.').pop()}`;

    


    // Create a new OdometerPicture entry
    const newOdometerPicture = await OdometerPictureModel.create({
      MemberID,
      OdometerPicture:imageData,
      SubmissionDate,
      ApprovalStatus,
      ReasonForRejection,
      Distance,
      MimeType: mimeType, 
      
    });





  


    res.json({ success: true, message: 'Odometer picture added successfully', data: newOdometerPicture });
  } catch (error) {
    res.status(500).json({ success: false, message: 'Internal server error', error: error.message });
  }
};



function convertImageToBase64(imagePath) {
  try {
    // Read the image file as a buffer
    const imageBuffer = fs.readFileSync(imagePath);

    // Convert the buffer to a base64 encoded string
    const base64String = imageBuffer.toString('base64');

    // Determine the mime type of the image
    const mimeType = `data:image/${imagePath.split('.').pop()};base64`;

    // Construct the data URI
    const dataURI = `${mimeType},${base64String}`;

    return dataURI;
  } catch (error) {
    throw new Error('Failed to convert image to base64: ' + error.message);
  }
}




async function getallOdometerByMemberID(req, res) {
  try {
    const odometerPictures = await OdometerPictureModel.findAll({
      where: {
        ApprovalStatus: 'Pending'
      },
      include: [
        {
          model: Member,
          attributes: ['Name','MemberID']
        }
      ]
    });

    const formattedData = await Promise.all(odometerPictures.map(async (record) => {
      const currentPendingImage = await OdometerPictureModel.findOne({
        where: {
          // MemberID: record.Member.MemberID,
          ApprovalStatus: 'Pending'
        },
        order: [['createdAt', 'DESC']]
      });

      if (!currentPendingImage) {
        return null;
      }

      const lastAcceptedImage = await OdometerPictureModel.findOne({
        where: {
          MemberID: record.Member.MemberID,
          ApprovalStatus: 'Accepted',
          createdAt: {
            [Op.lte]: currentPendingImage.createdAt
          }
        },
        order: [['createdAt', 'DESC']]
      });

      const currentImageBuffer = currentPendingImage.OdometerPicture;
      const base64StringC = currentImageBuffer.toString('base64');
      const mimeTypeC = currentPendingImage.MimeType;

      const dataURICurrent = `data:${mimeTypeC};base64,${base64StringC}`;

      let dataURILastAccepted = null;
      if (lastAcceptedImage) {
        const lastAcceptedImageBuffer = lastAcceptedImage.OdometerPicture;
        const base64StringP = lastAcceptedImageBuffer.toString('base64');
        const mimeTypeP = lastAcceptedImage.MimeType;
        dataURILastAccepted = `data:${mimeTypeP};base64,${base64StringP}`;
      }

      return {
        MemberID: record.Member.MemberID,
        MemberName: record.Member.Name,
        currentImage: dataURICurrent,
        lastAcceptedImage: dataURILastAccepted,
        SubmissionDate: record.SubmissionDate,
        ReasonForRejection: record.ReasonForRejection,
        Distance: record.Distance,
        ApprovalStatus: record.ApprovalStatus
      };
    }));

    // Filter out any null values (where no pending image was found)
    const filteredData = formattedData.filter(item => item !== null);

    res.json(filteredData);
  } catch (error) {
    res.status(500).json({ error: 'Internal Server Error' });
  }
}












// async function getOdometerPicturesByMemberID(memberID) {
//   try {
//     const currentPendingImage = await OdometerPictureModel.findOne({
//       where: {
//         MemberID: memberID,
//         ApprovalStatus: 'Pending'
//       },
//       order: [['createdAt', 'DESC']]
//     });

//     if (!currentPendingImage) {
//       throw new Error('No pending images found for the given memberID');
//     }

//     const lastAcceptedImage = await OdometerPictureModel.findOne({
//       where: {
//         MemberID: memberID,
//         ApprovalStatus: 'Accepted',
//         createdAt: {
//           [Op.lt]: currentPendingImage.createdAt
//         }
//       },
//       order: [['createdAt', 'DESC']]
//     });

//     const currentImageBuffer = currentPendingImage.OdometerPicture;

//     let base64StringC = currentImageBuffer.toString('base64');
//     let mimeTypeC = currentPendingImage.MimeType; // Use the stored MimeType

//     const dataURICurrent = `data:${mimeTypeC};base64,${base64StringC}`;

//     let dataURILastAccepted = null;
//     if (lastAcceptedImage) {
//       const lastAcceptedImageBuffer = lastAcceptedImage.OdometerPicture;
//       let base64StringP = lastAcceptedImageBuffer.toString('base64');
//       let mimeTypeP = lastAcceptedImage.MimeType; // Use the stored MimeType
//       dataURILastAccepted = `data:${mimeTypeP};base64,${base64StringP}`;
//     }

//     return {
//       currentImage: dataURICurrent,
//       lastAcceptedImage: dataURILastAccepted
//     };
//   } catch (error) {
//     throw new Error('Failed to retrieve Odometer Pictures: ' + error.message);
//   }
// }




const updateApprovalStatus = async (req, res) => {
  try {
    const { PictureID, ApprovalStatus, MemberID } = req.body;

    // Check if PictureID and ApprovalStatus are provided
    if (!PictureID || !ApprovalStatus) {
      return res.status(400).json({ message: 'PictureID and ApprovalStatus are required.' });
    }

    // Find the OdometerPicture record by PictureID
    const odometerPicture = await OdometerPictureModel.findOne({
      where: { PictureID: PictureID }
    });

    // If the record is not found, return a 404 error
    if (!odometerPicture) {
      return res.status(404).json({ message: 'OdometerPicture not found.' });
    }

    // Update the ApprovalStatus field
    await odometerPicture.update({ ApprovalStatus: ApprovalStatus });

    let Member_pic = await Member.findByPk(MemberID);

    if (ApprovalStatus == "Accepted" && Member_pic.Level == 1) {
      console.log("member Balance:",Member_pic.Balance);
      console.log("distance",odometerPicture.Distance)
      Member_pic.Balance =  parseInt(Member_pic.Balance, 10)  + odometerPicture.Distance * 0.4;
      await Member_pic.save();
    }
    else if (ApprovalStatus == "Accepted" && Member_pic.Level == 2) {
      console.log("member Balance:",Member_pic.Balance);
      console.log("distance",odometerPicture.Distance)
      Member_pic.Balance = parseInt(Member_pic.Balance, 10) + odometerPicture.Distance * 0.2 ;
      await Member_pic.save();
    }
    else if (ApprovalStatus == "Accepted" && Member_pic.Level == 3) {
      console.log("member Balance:",Member_pic.Balance);
      console.log("distance",odometerPicture.Distance)
      Member_pic.Balance = parseInt(Member_pic.Balance, 10)  + odometerPicture.Distance * 0.1;
      await Member_pic.save();
    }

    return res.status(200).json({
      message: 'ApprovalStatus updated successfully.',
      ApprovalStatus,
      UpdatedBalance: Member_pic.Balance  // Include the updated balance in the response
    });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ message: 'Internal Server Error.' });
  }
};
























module.exports = {
  addOdometer,
  updateApprovalStatus,
 
  getallOdometerByMemberID

};