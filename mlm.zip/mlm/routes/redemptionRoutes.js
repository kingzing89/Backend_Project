const express = require('express');
const router = express.Router();
const { submitRedemptionRequest, getAllPendingRedemptionRequests, updateRedemptionRequestStatus, getAllRedemptionRequestsBymemberID } = require('../controllers/redemptionController');

// Route to submit a redemption request
router.post('/submit-redemption-request', submitRedemptionRequest);

// Route to fetch all pending redemption requests
router.get('/pending-redemption-requests', getAllPendingRedemptionRequests);

// Route to update the status of a redemption request
router.post('/update-redemption-request-status', updateRedemptionRequestStatus);

router.get('/', getAllRedemptionRequestsBymemberID);

module.exports = router;
